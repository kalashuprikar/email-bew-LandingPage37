import PlaceholderPage from "./PlaceholderPage";

export default function Campaigns() {
  return (
    <PlaceholderPage
      title="Build for Campaigns"
      description="Campaign builder and management tools will be available here."
    />
  );
}
