import PlaceholderPage from "./PlaceholderPage";

export default function MyDownloads() {
  return (
    <PlaceholderPage
      title="My download List"
      description="Your download history and file management will be available here."
    />
  );
}
