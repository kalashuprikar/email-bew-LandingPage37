import PlaceholderPage from "./PlaceholderPage";

export default function BulkFTB() {
  return (
    <PlaceholderPage
      title="Bulk FTB with Ofsint"
      description="This page will contain bulk FTB functionality with OSINT capabilities."
    />
  );
}
